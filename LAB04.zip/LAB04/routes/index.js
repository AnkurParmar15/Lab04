var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Home' });
});

router.get('/dog', function(req, res, next) {
  res.render('dog', { title: 'Dog' });
});


router.get('/cat', function(req, res, next) {
  res.render('cat', { title: 'Cat' });
});

module.exports = router;
